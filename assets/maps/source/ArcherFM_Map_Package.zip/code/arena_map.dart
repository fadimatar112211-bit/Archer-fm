// Standalone loader: dart:core only. Not compiled/tested yet.
import 'dart:collection';
import 'dart:convert';
import 'dart:math';

class ArenaMap {
  static const size = 96;
  final List<List<String>> grid;
  final Map<String, dynamic> data;
  ArenaMap(String gridText, String jsonText)
      : grid = const LineSplitter().convert(gridText).map((r) => r.split('')).toList(),
        data = jsonDecode(jsonText) as Map<String, dynamic>;

  static const moveCost = {'=': 1.0, 'B': 1.0, 'b': 1.0, '.': 1.25, ':': 1.6};
  Point<int> toCell(double x, double y) => Point((x + 48).floor(), (48 - y).floor());
  Point<double> toWorld(Point<int> c) => Point(c.x - 47.5, 47.5 - c.y);
  bool inside(int c, int r) => c >= 0 && r >= 0 && c < size && r < size;
  bool walkable(int c, int r) => inside(c, r) && moveCost.containsKey(grid[r][c]);
  bool blocksShot(int c, int r) => !inside(c, r) || '#RCT'.contains(grid[r][c]);

  bool lineOfSight(Point<double> a, Point<double> b) {
    final n = max(1, (a.distanceTo(b) * 4).ceil());
    for (var i = 0; i <= n; i++) {
      final p = toCell(a.x + (b.x - a.x) * i / n, a.y + (b.y - a.y) * i / n);
      if (blocksShot(p.x, p.y)) return false;
    }
    return true;
  }

  /// Call when a crystal is destroyed, then repath affected units.
  void destroyCrystal(String id) {
    for (final p in data['players']) {
      for (final k in p['crystals']) {
        if (k['id'] != id) continue;
        final f = (k['footprint'] as List).cast<num>();
        final a = toCell(f[0] + .5, f[3] - .5), b = toCell(f[2] - .5, f[1] + .5);
        for (var r = a.y; r <= b.y; r++) {
          for (var c = a.x; c <= b.x; c++) grid[r][c] = '.';
        }
      }
    }
  }

  /// A*, 8 directions, no corner cutting. Empty list = no path.
  List<Point<int>> findPath(Point<int> s, Point<int> g) {
    if (!walkable(s.x, s.y) || !walkable(g.x, g.y)) return [];
    int id(int c, int r) => r * size + c;
    double h(int c, int r) {
      final dx = (c - g.x).abs(), dy = (r - g.y).abs();
      return max(dx, dy) + (sqrt2 - 1) * min(dx, dy);
    }
    final open = SplayTreeSet<List<num>>((a, b) {
      final x = a[0].compareTo(b[0]);
      return x != 0 ? x : a[1].compareTo(b[1]);
    });
    final cost = <int, double>{id(s.x, s.y): 0};
    final from = <int, int>{};
    final done = <int>{};
    open.add([h(s.x, s.y), id(s.x, s.y)]);
    while (open.isNotEmpty) {
      final top = open.first;
      open.remove(top);
      var cur = top[1].toInt();
      if (!done.add(cur)) continue;
      final c = cur % size, r = cur ~/ size;
      if (c == g.x && r == g.y) {
        final path = [Point(c, r)];
        while (from.containsKey(cur)) {
          cur = from[cur]!;
          path.add(Point(cur % size, cur ~/ size));
        }
        return path.reversed.toList();
      }
      for (var dr = -1; dr <= 1; dr++) {
        for (var dc = -1; dc <= 1; dc++) {
          final x = c + dc, y = r + dr;
          if ((dr == 0 && dc == 0) || !walkable(x, y)) continue;
          if (dr != 0 && dc != 0 && (!walkable(x, r) || !walkable(c, y))) continue;
          final n = id(x, y);
          final nc = cost[cur]! + (dr != 0 && dc != 0 ? sqrt2 : 1) * moveCost[grid[y][x]]!;
          if (nc < (cost[n] ?? double.infinity)) {
            cost[n] = nc;
            from[n] = cur;
            open.add([nc + h(x, y), n]);
          }
        }
      }
    }
    return [];
  }
}

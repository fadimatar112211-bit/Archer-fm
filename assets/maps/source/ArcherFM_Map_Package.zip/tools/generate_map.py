import json,math,heapq,random,os
from PIL import Image,ImageDraw,ImageFont,ImageFilter
os.chdir(os.path.dirname(os.path.abspath(__file__))+'/..')
N=96
def rot(p,k):
    x,y=p
    for _ in range(k): x,y=-y,x
    return (x,y)
def W(s,d,k): return rot((s,-d),k)
def R(r,k):
    s1,s2,d1,d2=r; a=W(s1,d1,k); b=W(s2,d2,k)
    return [min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1])]
PN=['P1 South','P2 East','P3 North','P4 West']
PC=[(59,130,246),(239,68,68),(250,190,30),(168,85,247)]
CR=[('C1','heart',0,46,3500),('C2','inner',-8,42,2500),('C3','inner',8,42,2500),('C4','mid',-13,36,2000),('C5','mid',13,36,2000),('C6','outer',-11,28,1500),('C7','outer',11,28,1500)]
m={'name':'Archer FM Arena v1','units':'1 unit = 1 m = 1 nav cell','size':[96,96],'origin':'map center; +X east, +Y north, +Z up','symmetry':'D4','players':[],'walls':[],'rocks':[],'camps':[],'points':[]}
for k in range(4):
    p={'id':f'P{k+1}','side':PN[k],'color':'#%02x%02x%02x'%PC[k],'castle':R((-4,4,36,44),k),'spawn':list(W(0,33.5,k)),'cameraYawDeg':(45+90*k)%360,'crystals':[],'towers':[]}
    for i,t,s,d,hp in CR:
        x,y=W(s,d,k); p['crystals'].append({'id':f'P{k+1}-{i}','tier':t,'x':x,'y':y,'footprint':[x-1,y-1,x+1,y+1],'hp':hp})
    for j,sg in enumerate((-1,1)):
        def f(a,b,c,d,sg=sg): return (min(sg*a,sg*b),max(sg*a,sg*b),c,d)
        S='LR'[j]
        p['towers'].append({'id':f'P{k+1}-T{S}','rect':R(f(6,8,30,32),k),'range':9})
        for n,r in (('A',(4,11,38,40)),('B',(10,16,32,34)),('G',(4,6,30,32))):
            m['walls'].append({'id':f'P{k+1}-W{n}{S}','rect':R(f(*r),k)})
        m['rocks'].append({'id':f'P{k+1}-Rk{S}','rect':R(f(6,9,25,27),k)})
        x,y=W(sg*21,37,k); m['camps'].append({'id':f'P{k+1}-Gob{S}','type':'goblin','x':x,'y':y,'count':3,'leash':5,'spawnSec':30,'respawnSec':60})
    m['players'].append(p)
for k,(a,b) in enumerate([(1,-1),(1,1),(-1,1),(-1,-1)]):
    for n,u,v in (('Mid',4,8),('Cor',28,32)):
        m['rocks'].append({'id':f'{n}-Rk{k+1}','rect':[min(u*a,v*a),min(u*b,v*b),max(u*a,v*a),max(u*b,v*b)]})
    for t,v,c,ls,sp,rs in (('wolf',25.5,2,5,60,90),('golem',11,1,4,120,150)):
        m['camps'].append({'id':f'{t}{k+1}','type':t,'x':v*a,'y':v*b,'count':c,'leash':ls,'spawnSec':sp,'respawnSec':rs})
    m['points'].append({'id':f'ManaWell{k+1}','x':38*a,'y':38*b,'captureRadius':3})
m['camps'].append({'id':'drake','type':'crystal_drake','x':0,'y':0,'count':1,'leash':8,'spawnSec':300,'respawnSec':240})
m['points'].append({'id':'CentralAltar','x':0,'y':0,'captureRadius':5})
m['river']={'centerRadius':'21 + 1.2*cos(4*theta)','width':5,'waterZ':-0.8}
m['bridges']=[{'id':f'{n}{k+1}','center':[round(v,2) for v in rot(c,k)],'width':w} for n,c,w in (('Main',(0,-22.2),8),('Flank',(14,-14),4)) for k in range(4)]
inr=lambda x,y,r:r[0]<x<r[2] and r[1]<y<r[3]
def cell(x,y):
    r=math.hypot(x,y); ax,ay=abs(x),abs(y); diag=abs(ax-ay)<=2.97
    for p in m['players']:
        if inr(x,y,p['castle']):return 'C'
        if any(inr(x,y,t['rect']) for t in p['towers']):return 'T'
        if any(inr(x,y,c['footprint']) for c in p['crystals']):return 'K'
    if any(inr(x,y,w['rect']) for w in m['walls']):return '#'
    if any(inr(x,y,w['rect']) for w in m['rocks']):return 'R'
    if abs(r-(21+1.2*math.cos(4*math.atan2(y,x))))<2.5:
        return 'B' if min(ax,ay)<4 else ('b' if diag else '~')
    if (min(ax,ay)<4 and max(ax,ay)<=33) or 31<=r<=34.5 or (diag and 11<=r<=31):return '='
    if min(ax,ay)>34:return ':'
    return '.'
G=[[cell(c-47.5,47.5-r) for c in range(N)] for r in range(N)]
assert all(G[r][c]==G[N-1-c][r] and G[r][c]==G[r][N-1-c] for r in range(N) for c in range(N)),'symmetry'
cl=lambda v:max(0,min(1,v))
def hgt(x,y):
    ax,ay=abs(x),abs(y)
    h=cl((max(ax,ay)-32)/3) if min(ax,ay)<=17 else 0
    return h+1.5*cl((min(ax,ay)-34)/3)+.6*cl((6-math.hypot(x,y))/1.5)
COST={'=':1,'B':1,'b':1,'.':1.25,':':1.6}
def idx(x,y):return (int(math.floor(48-y)),int(math.floor(x+48)))
def dij(srcs):
    D={s:0 for s in srcs};q=[(0,s) for s in srcs]
    while q:
        d,(r,c)=heapq.heappop(q)
        if d>D[(r,c)]:continue
        for dr in(-1,0,1):
            for dc in(-1,0,1):
                a,b=r+dr,c+dc
                if (dr,dc)==(0,0) or not(0<=a<N and 0<=b<N) or G[a][b] not in COST:continue
                if dr and dc and (G[r][b] not in COST or G[a][c] not in COST):continue
                nd=d+math.hypot(dr,dc)
                if nd<D.get((a,b),1e9):D[(a,b)]=nd;heapq.heappush(q,(nd,(a,b)))
    return D
def near(D,x,y,rad):
    return min(v for(r,c),v in D.items() if max(abs(c-47.5-x),abs(47.5-r-y))<=rad)
res=[]
for k in range(4):
    D=dij([idx(*rot((x,-33.5),k)) for x in (-.5,.5)]);row={'المركز (المذبح)':near(D,0,0,.6)}
    for lab,j in (('الخصم على اليمين',1),('الخصم المقابل',2),('الخصم على اليسار',3)):
        row[lab]=min(D[idx(*rot((x,-33.5),(k+j)%4))] for x in (-.5,.5))
    for t in ('goblin','wolf','golem'):
        row['أقرب '+t]=min(near(D,c['x'],c['y'],1) for c in m['camps'] if c['type']==t)
    for c in m['players'][k]['crystals']: row['بلورتك '+c['id'][3:]]=near(D,c['x'],c['y'],1.6)
    res.append({a:round(b,1) for a,b in row.items()})
assert all(r==res[0] for r in res),res
m['validatedPathLengthsFromSpawn']=res[0]
json.dump(m,open('data/archer_fm_map.json','w'),indent=1)
open('data/nav_grid.txt','w').write('\n'.join(''.join(r) for r in G)+'\n')
open('data/height_map.csv','w').write('\n'.join(','.join(f'{hgt(c-47.5,47.5-r):.2f}' for c in range(N)) for r in range(N)))
F='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=lambda s:ImageFont.truetype(F,s)
COL={'.':(104,163,72),'=':(176,164,138),':':(133,128,112),'B':(214,190,150),'b':(196,170,128),'~':(46,148,196),'#':(98,94,104),'R':(110,103,96),'C':(90,90,120),'T':(80,70,90),'K':(180,240,255)}
def flat(colors,name,labels=True):
    S=20;im=Image.new('RGB',(96*S,96*S));d=ImageDraw.Draw(im)
    for r in range(N):
        for c in range(N):d.rectangle([c*S,r*S,c*S+S-1,r*S+S-1],fill=colors[G[r][c]],outline=None if labels else (90,90,90))
    P=lambda x,y:((x+48)*S,(48-y)*S)
    def T(x,y,s,z=18):d.text(P(x,y),s,font=font(z),fill='white',anchor='mm',stroke_width=3,stroke_fill='black')
    if labels:
        for v in range(-40,41,8):
            d.line([P(v,-48),P(v,48)],fill=(70,90,60));d.line([P(-48,v),P(48,v)],fill=(70,90,60));T(v,.8,str(v),15);T(1.8,v,str(v),15)
        for k,p in enumerate(m['players']):
            x0,y0,x1,y1=p['castle'];d.rectangle([P(x0,y1),P(x1,y0)],fill=PC[k]);T((x0+x1)/2,(y0+y1)/2,p['id'],42)
            for c in p['crystals']:
                X,Y=P(c['x'],c['y']);d.polygon([(X,Y-22),(X+18,Y),(X,Y+22),(X-18,Y)],fill=PC[k],outline='white');T(c['x'],c['y'],c['id'][3:],15)
            for t in p['towers']:a=t['rect'];T((a[0]+a[2])/2,(a[1]+a[3])/2,'TW',15)
            T(*p['spawn'],'SPAWN')
        for c in m['camps']:T(c['x'],c['y'],c['type'].upper(),19)
        for c in m['points']:T(c['x'],c['y']-(3 if c['x']==0 else 0),c['id'],19)
        for b in m['bridges']:T(*b['center'],b['id'],17)
    im.save('images/'+name)
    return im
top=flat(COL,'01_topdown.png')
flat({**{k:(40,200,90) for k in '=Bb'},'.':(170,215,90),':':(230,175,60),**{k:(45,45,55) for k in '~#RCTK'}},'03_nav_grid.png',False)
flat({**{k:(235,235,235) for k in '=Bb.:'},'~':(40,120,230),'#':(210,40,40),'R':(140,80,40),'C':(60,30,90),'T':(230,100,200),'K':(0,190,190)},'04_collision.png',False)
def iso(name,k,ctr):
    random.seed(7);WW,HH=3840,2160
    im=Image.new('RGB',(WW,HH),(24,38,48));d=ImageDraw.Draw(im,'RGBA');q=math.sqrt(.5);sp,cp=math.sin(math.radians(48)),math.cos(math.radians(48))
    def P(x,y,z):
        x-=ctr[0];y-=ctr[1]
        return (WW/2+(x+y)*q*k, HH/2-((-x+y)*q*sp+z*cp)*k)
    sh=lambda c,f:tuple(max(0,min(255,int(v*f))) for v in c)
    def box(a,z0,z1,col):
        x0,y0,x1,y1=a
        d.polygon([P(x0,y0,z0),P(x1,y0,z0),P(x1,y0,z1),P(x0,y0,z1)],fill=sh(col,.72))
        d.polygon([P(x1,y0,z0),P(x1,y1,z0),P(x1,y1,z1),P(x1,y0,z1)],fill=sh(col,.55))
        d.polygon([P(x0,y0,z1),P(x1,y0,z1),P(x1,y1,z1),P(x0,y1,z1)],fill=col)
    depth=lambda x,y:-x+y
    for r,c in sorted([(r,c) for r in range(N) for c in range(N)],key=lambda t:-depth(t[1]-47.5,47.5-t[0])):
        x,y=c-47.5,47.5-r;t=G[r][c]
        base=t if t in '.=:~Bb' else ('.' if min(abs(x),abs(y))>4 else '=')
        z=-.8 if base=='~' else hgt(x,y)+(.35 if base in 'Bb' else 0)
        box([x-.5,y-.5,x+.5,y+.5],-2,z,sh(COL[base],random.uniform(.91,1.08)))
    objs=[]
    def add(x,y,f):objs.append((depth(x,y),f))
    def cone(x,y,z,rad,h,col):
        pts=[P(x+rad*math.cos(i*math.pi/6),y+rad*math.sin(i*math.pi/6),z) for i in range(13)];a=P(x,y,z+h)
        for i in sorted(range(12),key=lambda i:-depth(math.cos((i+.5)*math.pi/6),math.sin((i+.5)*math.pi/6))):
            d.polygon([pts[i],pts[i+1],a],fill=sh(col,.8+.35*math.cos(i*math.pi/6+2)))
    def castle(a,col):
        x0,y0,x1,y1=a;cx,cy=(x0+x1)/2,(y0+y1)/2;z=hgt(cx,cy);box([x0+.6,y0+.6,x1-.6,y1-.6],z,z+3.5,(188,180,166))
        for tx,ty in sorted([(x0+1,y0+1),(x1-1,y0+1),(x1-1,y1-1),(x0+1,y1-1),(cx,cy)],key=lambda t:-depth(*t)):
            h=7 if (tx,ty)==(cx,cy) else 4.8;box([tx-1,ty-1,tx+1,ty+1],z,z+h,(204,196,180));cone(tx,ty,z+h,1.6,2.8,col)
    def tower(x,y,col):
        z=hgt(x,y);box([x-.8,y-.8,x+.8,y+.8],z,z+3,(180,172,160));cone(x,y,z+3,1.3,1.8,col)
    def crystal(x,y,col):
        z=hgt(x,y)
        gl=Image.new('RGBA',(int(8*k),int(6*k)),(0,0,0,0));ImageDraw.Draw(gl).ellipse([2*k,1.8*k,6*k,4.2*k],fill=col+(160,))
        gl=gl.filter(ImageFilter.GaussianBlur(k*.6));X,Y=P(x,y,z);im.paste(gl,(int(X-4*k),int(Y-3*k)),gl)
        cone(x,y,z+1.7,1.1,2.4,sh(col,1.35))
        ring=[P(x+1.1*math.cos(j*math.pi/3),y+1.1*math.sin(j*math.pi/3),z+1.7) for j in range(6)];b=P(x,y,z+.1)
        for j in (3,4,5,0):d.polygon([ring[j],ring[(j+1)%6],b],fill=sh(col,.65+.12*(j%3)))
        X,Y=P(x,y,z+4.8);d.rectangle([X-k,Y,X+k,Y+.3*k],fill=(25,25,25));d.rectangle([X-k+2,Y+2,X+k-2,Y+.3*k-2],fill=(90,230,90))
    def chibi(x,y,col,s):
        z=hgt(x,y);X,Y=P(x,y,z);u=k*s
        d.ellipse([X-.7*u,Y-.28*u,X+.7*u,Y+.28*u],fill=(0,0,0,90))
        d.ellipse([X-.45*u,Y-1*u,X+.45*u,Y],fill=col,outline=(20,20,20),width=2)
        d.ellipse([X-.58*u,Y-1.95*u,X+.58*u,Y-.8*u],fill=(246,207,170),outline=(20,20,20),width=2)
        d.pieslice([X-.62*u,Y-2.05*u,X+.62*u,Y-.9*u],180,360,fill=sh(col,.8))
        for e in(-.22,.22):d.ellipse([X+(e-.08)*u,Y-1.3*u,X+(e+.08)*u,Y-1.1*u],fill=(25,25,35))
        d.rectangle([X-.7*u,Y-2.4*u,X+.7*u,Y-2.2*u],fill=(70,230,80),outline=(0,0,0))
    for i,p in enumerate(m['players']):
        a=p['castle'];add((a[0]+a[2])/2,(a[1]+a[3])/2,lambda a=a,c=PC[i]:castle(a,c))
        for t in p['towers']:
            a=t['rect'];x,y=(a[0]+a[2])/2,(a[1]+a[3])/2;add(x,y,lambda x=x,y=y,c=PC[i]:tower(x,y,c))
        for c in p['crystals']:add(c['x'],c['y'],lambda x=c['x'],y=c['y'],col=PC[i]:crystal(x,y,col))
        for s,dd,sz in [(-2,24,.8),(0,24.5,.8),(2,24,.8),(-1,26,.8),(1,26,.8),(0,29,1.4)]:
            x,y=W(s,dd,i);add(x,y,lambda x=x,y=y,c=PC[i],z=sz:chibi(x,y,c,z))
    for w in m['walls']+m['rocks']:
        x0,y0,x1,y1=w['rect'];wall='-W' in w['id']
        for x in range(x0,x1):
            for y in range(y0,y1):
                h=2.1 if wall else random.uniform(.8,2.2);add(x+.5,y+.5,lambda x=x,y=y,h=h,wall=wall:box([x,y,x+1,y+1],hgt(x,y),hgt(x,y)+h,(150,142,156) if wall else (125,116,104)))
    mc={'goblin':((95,150,50),.85),'wolf':((120,120,140),1.1),'golem':((125,95,70),1.9),'crystal_drake':((20,170,190),3)}
    for c in m['camps']:
        col,s=mc[c['type']]
        for j in range(c['count']):
            x=c['x']+1.3*j-.65*(c['count']-1);add(x,c['y'],lambda x=x,y=c['y'],col=col,s=s:chibi(x,y,col,s))
    for _,f in sorted(objs,key=lambda t:-t[0]):f()
    def txt(xy,s,z,col='white'):d.text(xy,s,font=font(z),fill=col,anchor='mm',direction='rtl',stroke_width=4,stroke_fill=(0,0,0))
    txt(P(*rot((1,-25),0),3),'128',50,(255,215,60))
    d.rounded_rectangle([50,50,800,270],30,fill=(10,16,26,210));txt((425,115),'اللاعب ١  •  ذهب ٤٥٠',52);txt((425,200),'البلورات ٧/٧  •  مستوى الجيش ٣',44)
    mm=top.resize((380,380),Image.LANCZOS).convert('RGBA').rotate(45,expand=True);mm.thumbnail((450,450));im.paste(mm,(WW-490,30),mm)
    d.ellipse([110,1750,440,2080],fill=(255,255,255,40),outline='white',width=6);d.ellipse([215,1855,335,1975],fill=(255,255,255,150))
    for X,Y,r,s in [(3620,1940,140,'هجوم'),(3350,2020,85,'١'),(3390,1800,85,'٢'),(3560,1650,85,'٣'),(3740,1560,70,'٤')]:
        d.ellipse([X-r,Y-r,X+r,Y+r],fill=(20,40,70,210),outline=(255,210,90),width=7);txt((X,Y),s,52)
    im.resize((1920,1080),Image.LANCZOS).save('images/'+name)
iso('02_isometric_full.png',20,(0,0))
iso('05_isometric_gameplay.png',72,(2,-31))
print(res[0])
from collections import Counter
print(Counter(''.join(map(''.join,G))))

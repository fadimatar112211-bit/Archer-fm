# حزمة وحوش Archer FM (GLB)

أربعة وحوش ثلاثية الأبعاد مجسّمة ومحرّكة (Skinned + Animated) بصيغة GLB، مبنية على نماذج vinish.dev (CC BY 4.0) ومعدّلة. ملف **CREDITS.txt** مطلوب ترخيصاً.

## المحتوى

```
assets/monsters/
  monsters_manifest.json        فهرس الوحوش والأدوار
  <id>/<id>.glb                 النموذج (Mesh + عظام + حركات + خامات مدمجة)
  <id>/monster.json             مواصفات: حركات، مدد، تقديرات، أرقام
  <id>/textures/                نسخة من صور الخامات المدمجة (للاطلاع فقط)
  <id>/preview/                 hero.png, hero_transparent.png, game_camera.png, animations_sheet.png
CREDITS.txt  LICENSE_SOURCE.txt  REPORT_AR.md
tools/                          سكربتات المعالجة والعارض والمعاينة
```

## الوحوش والأدوار

| المعرّف | الاسم | الدور |
|---|---|---|
| `bog-monster` | Bog Monster | الوحش العادي |
| `werewolf` | Werewolf | الوحش السريع |
| `stone-golem` | Stone Golem | الوحش الثقيل (هجوم منطقة AOE) |
| `blind-stalker` | Blind Stalker | الوحش المتخفي |

## مواصفات مشتركة

- glTF 2.0، وحدة القياس متر، المحور الأعلى +Y، الأمام +Z، والمركز عند القدمين (Y=0).
- حركات بأسماء ثابتة: `Idle` `Walk` `Run` `Attack` `Roar` `Die` `Hit`. التكرار: Idle/Walk/Run متكررة، والبقية تُشغَّل مرة واحدة (Die تبقى على آخر إطار).
- الحجم النهائي مدمج في عقدة Root (scale)، فلا تضف مقياساً إضافياً إلا للضبط.
- Walk/Run في المكان: حرّك الوحش من كود اللعبة. السرعات المقترحة لمنع انزلاق القدمين في `monster.json` ← `estimates`.
- حركة `Hit` لا تغيّر موضع الوحش، وتدوم نحو 0.45 ث. شغّلها فوق Idle أو بتدرّج (crossfade).

## طريقة الاستيراد

**لم أختبر أياً مما يلي داخل مشروعك**؛ هذه إرشادات عامة، تحقق من إصدارات الحزم وواجهاتها.

- **Unity / Godot / Unreal / three.js**: تستورد GLB مباشرة وتعرض أسماء الحركات أعلاه.
- **Flutter**: Flutter لا يعرض GLB مجسّماً أصلاً. الخيارات الشائعة: (1) حزم مبنية على `<model-viewer>` عبر WebView مثل `model_viewer_plus` أو `flutter_3d_controller` وهي سهلة لكن ثقيلة لعدة وحوش في المشهد؛ (2) `flutter_scene` (Flutter GPU) لتحميل النماذج، وهي حديثة وتحتاج خطوة استيراد؛ (3) **الأنسب للعبة 2.5D**: تحويل كل حركة إلى Sprite Sheet من زاوية كاميرا اللعبة مرة واحدة، ثم استخدامها في Flame/Canvas. العارض `tools/viewer.html` مع `tools/drive.js` يصوّر أي حركة/زاوية من GLB، ويمكن بناء خط تصيير الإطارات عليه.
- ربط المنطق: أبقِ `MonsterManager` وأنواع الوحوش كما هي، وأضف جدول ربط من النوع إلى `<id>.glb` حسب الدور أعلاه. لم أعدّل مشروعك ولا أعرف أسماء أنواعك بدقة.

## ملاحظات لكل دور

- **Stone Golem (AOE)**: لا توجد مؤثرات جاهزة. أطلق الموجة عند لحظة الضرب `attack_impact_time_s` من `monster.json` (تقدير) واضبطها بصرياً.
- **Blind Stalker (تخفٍّ)**: مواده معتمة. نفّذ التخفي بتقليل الشفافية أو tint في المحرك.

## إعادة التوليد أو تعديل النسب

سكربتات Python (numpy فقط) داخل `tools/`: `process.py <id>` يقرأ GLB الأصلي من `src/monsters/` ويكتب `build/<id>.glb`. عدّل `CFG` (head/thigh/arm/height/budget/recoil). التحليل: `analyze.py`. التصيير: `drive.js` (Playwright + Chromium).

## الترخيص

CC BY 4.0. أدرج أسطر CREDITS.txt في شاشة حقوق اللعبة. تفاصيل التعديلات المذكورة فيه إلزامية.

التقرير الكامل بالأرقام: `REPORT_AR.md`.

import glb, json, numpy as np, sys
from process import trs
NAMES=['bog-monster','werewolf','stone-golem','blind-stalker']
def analyze(n):
    j,b=glb.load(f'build/{n}.glb'); R={'name':n,'checks':[]}
    nodes=j['nodes']; names=[x.get('name') for x in nodes]; ix={x:i for i,x in enumerate(names) if x}
    # --- structural checks
    ok=True
    def chk(c,msg): 
        nonlocal ok; R['checks'].append((bool(c),msg)); ok&=bool(c)
    chk(sum(bv['byteOffset']+bv['byteLength'] for bv in j['bufferViews'][-1:])<=len(b)+4,'bufferViews inside BIN chunk')
    nj=len(j['skins'][0]['joints']); tris=0; verts=0
    for p in j['meshes'][0]['primitives']:
        P=glb.acc(j,b,p['attributes']['POSITION']); I=glb.acc(j,b,p['indices']); Jn=glb.acc(j,b,p['attributes']['JOINTS_0']); W=glb.acc(j,b,p['attributes']['WEIGHTS_0']).astype(float)
        W/= {np.dtype('uint16'):65535.,np.dtype('uint8'):255.}.get(W.dtype if False else glb.acc(j,b,p['attributes']['WEIGHTS_0']).dtype,1.)
        chk(I.max()<len(P),f'indices < vertex count ({j["materials"][p["material"]]["name"]})')
        chk(Jn.max()<nj,'joint ids valid'); chk(abs(W.sum(1)-1).max()<0.01,'weights sum to 1 (max err %.4f)'%abs(W.sum(1)-1).max())
        chk(np.isfinite(P).all(),'finite positions'); tris+=len(I)//3; verts+=len(P)
        N=glb.acc(j,b,p['attributes']['NORMAL']); chk(np.isfinite(N).all(),'finite normals')
        if 'TEXCOORD_0' in p['attributes']: chk(np.isfinite(glb.acc(j,b,p['attributes']['TEXCOORD_0'])).all(),'finite UVs')
    R['tris']=tris; R['verts']=verts; R['allpass']=ok
    R['bones']=[names[i] for i in j['skins'][0]['joints']]
    R['materials']=[m.get('name') for m in j['materials']]
    R['images']=len(j['images'])
    # --- animation analysis (FK incl. root scale)
    parent=[-1]*len(nodes)
    for i,x in enumerate(nodes):
        for c in x.get('children',[]): parent[c]=i
    anims={}
    for a in j['animations']:
        anims[a['name']]=[(c['target']['node'],c['target']['path'],glb.acc(j,b,a['samplers'][c['sampler']]['input']).reshape(-1),glb.acc(j,b,a['samplers'][c['sampler']]['output'])) for c in a['channels']]
    def pose_at(an,t):
        pose={}
        for node,path,T,V in anims[an]:
            tt=min(t,T[-1]); k=min(np.searchsorted(T,tt,side='right')-1,len(T)-2) if len(T)>1 else 0
            f=0 if len(T)==1 else (tt-T[k])/(T[k+1]-T[k]) ; v0=V[k]; v1=V[min(k+1,len(T)-1)]
            if path=='rotation':
                d=np.dot(v0,v1); v1=v1 if d>=0 else -v1; v=v0+(v1-v0)*f; v=v/np.linalg.norm(v)
            else: v=v0+(v1-v0)*f
            pose.setdefault(node,{})[path]=v
        return pose
    def world(an,t,names_):
        pose=pose_at(an,t); G={}
        def g(i):
            if i in G: return G[i]
            nd=nodes[i]; p=pose.get(i,{}); L=trs(p.get('translation',nd.get('translation',[0,0,0])),p.get('rotation',nd.get('rotation',[0,0,0,1])),nd.get('scale',[1,1,1]))
            G[i]=L if parent[i]<0 else g(parent[i])@L; return G[i]
        return {k:g(ix[k])[:3,3] for k in names_}
    dur={a:max(x[2][-1] for x in anims[a]) for a in anims}; R['dur']=dur
    # attack impact estimate: time of fastest downward hand motion after the hand's peak height
    ts=np.linspace(0,dur['Attack'],121); H=np.array([[*world('Attack',t,['Hand_L','Hand_R']).values()] for t in ts])  # (T,2,3)
    best=None
    for h in range(2):
        y=H[:,h,1]; kpk=int(np.argmax(y)); v=np.gradient(y,ts); kk=kpk+int(np.argmin(v[kpk:])); 
        sc=y[kpk]-y.min()
        if best is None or sc>best[0]: best=(sc,['Hand_L','Hand_R'][h],float(ts[kpk]),float(ts[kk]),float(y[kpk]),float(y[kk]))
    R['attack']=dict(hand=best[1],peak_t=round(best[2],2),impact_t=round(best[3],2),peak_y=round(best[4],2),impact_y=round(best[5],2))
    # stride estimate
    for an in ('Walk','Run'):
        ts=np.linspace(0,dur[an],61); Fz=np.array([[*world(an,t,['Foot_L','Foot_R']).values()] for t in ts])[:,:,2]
        exc=float((Fz.max(0)-Fz.min(0)).mean()); R[an+'_ground_speed']=round(exc/(dur[an]/2),2); R[an+'_foot_excursion']=round(exc,2)
    return R
if __name__=='__main__':
    out=[analyze(n) for n in NAMES]; json.dump(out,open('analysis.json','w'),indent=1,default=str)
    for r in out: print(r['name'],'pass' if r['allpass'] else 'FAIL',r['tris'],r['verts'],r['attack'],r['Walk_ground_speed'],r['Run_ground_speed'],[c for c in r['checks'] if not c[0]])

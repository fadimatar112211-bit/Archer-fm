import numpy as np, heapq

def decimate(P, F, target_faces, extra_pin=None, weights=None, wpen=0.0, pin_seams=True, return_alive=False):
    """Edge-collapse where the removed vertex v merges into kept vertex u (u keeps position and
    all attributes), so UV/normal/skin data never needs interpolation and no cracks open.
    Vertices that share a position with another vertex (UV/normal seams) or sit on a boundary
    are pinned (never removed). Returns new face array (indices into original vertex list)."""
    P = P.astype(np.float64); F = F.astype(np.int64).copy(); nV = len(P)
    # --- pinned: duplicated positions + boundary edges
    q = np.round(P * 1e5).astype(np.int64)
    _, inv, cnt = np.unique(q, axis=0, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    pinned = (cnt[inv] > 1) if pin_seams else np.zeros(nV, bool)
    e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]); es = np.sort(e, 1)
    keys = es[:, 0] * nV + es[:, 1]
    uk, uc = np.unique(keys, return_counts=True)
    bk = uk[uc == 1]
    pinned[(bk // nV)] = True; pinned[(bk % nV)] = True
    if extra_pin is not None: pinned |= extra_pin
    # --- quadrics
    p0, p1, p2 = P[F[:, 0]], P[F[:, 1]], P[F[:, 2]]
    nrm = np.cross(p1 - p0, p2 - p0); area = np.linalg.norm(nrm, axis=1)
    ok = area > 1e-14
    nn = np.zeros_like(nrm); nn[ok] = nrm[ok] / area[ok, None]
    d = -(nn * p0).sum(1)
    pl = np.concatenate([nn, d[:, None]], 1)
    K = (pl[:, :, None] * pl[:, None, :]) * (area[:, None, None] * 0.5)
    Q = np.zeros((nV, 4, 4))
    for k in range(3): np.add.at(Q, F[:, k], K)
    # --- adjacency
    vf = [set() for _ in range(nV)]
    for fi, f in enumerate(F):
        for v in f: vf[v].add(fi)
    alive = np.ones(len(F), bool); nalive = len(F)
    ver = np.zeros(nV, np.int64)
    removed = np.zeros(nV, bool)

    def nbrs(v):
        s = set()
        for fi in vf[v]:
            a, b, c = F[fi]; s.add(a); s.add(b); s.add(c)
        s.discard(v); return s

    def cost(v, u):
        h = np.append(P[u], 1.0)
        c = h @ (Q[v] + Q[u]) @ h
        if weights is not None and wpen > 0:
            c += wpen * np.abs(weights[v] - weights[u]).sum()
        return c

    heap = []
    def push_edge(a, b):
        if not pinned[a]: heapq.heappush(heap, (cost(a, b), a, b, ver[a], ver[b]))
        if not pinned[b]: heapq.heappush(heap, (cost(b, a), b, a, ver[b], ver[a]))
    seen = set()
    for a, b in es:
        k = (int(a), int(b))
        if k not in seen: seen.add(k); push_edge(int(a), int(b))

    def fnormal(fi, repl=None):
        a, b, c = F[fi]
        pa = P[a] if repl is None or a != repl[0] else P[repl[1]]
        pb = P[b] if repl is None or b != repl[0] else P[repl[1]]
        pc = P[c] if repl is None or c != repl[0] else P[repl[1]]
        return np.cross(pb - pa, pc - pa)

    while nalive > target_faces and heap:
        c, v, u, vv, vu = heapq.heappop(heap)
        if removed[v] or removed[u] or ver[v] != vv or ver[u] != vu: continue
        shared = vf[v] & vf[u]
        if not shared: continue
        # link condition
        nv, nu = nbrs(v), nbrs(u)
        if len((nv & nu)) != len(shared): continue
        # flip check
        bad = False
        for fi in vf[v] - shared:
            n0 = fnormal(fi); n1 = fnormal(fi, (v, u))
            l0 = np.linalg.norm(n0); l1 = np.linalg.norm(n1)
            if l1 < 1e-12 or (l0 > 1e-12 and np.dot(n0, n1) / (l0 * l1) < 0.25): bad = True; break
        if bad: continue
        # apply
        for fi in shared:
            alive[fi] = False; nalive -= 1
            for w in F[fi]: vf[w].discard(fi)
        for fi in list(vf[v]):
            F[fi][F[fi] == v] = u; vf[u].add(fi)
        vf[v] = set(); removed[v] = True; ver[u] += 1; ver[v] += 1
        Q[u] += Q[v]
        for w in nbrs(u):
            ver[w] += 0
            push_edge(u, w) if True else None
    return (F[alive], alive) if return_alive else F[alive]

def compact(F, arrays):
    used = np.unique(F); remap = -np.ones(used.max() + 1, np.int64); remap[used] = np.arange(len(used))
    return remap[F], [a[used] for a in arrays]


def decimate_welded(P, F, N, UV, target_faces):
    """Decimate on position-welded topology, then re-attach each corner to the closest original
    vertex copy (by UV, else normal) of its surviving welded vertex. Output indexes original verts."""
    q = np.round(P.astype(np.float64) * 1e5).astype(np.int64)
    uq, first, inv = np.unique(q, axis=0, return_index=True, return_inverse=True); inv = inv.ravel()
    Pw = P[first].astype(np.float64); Fw = inv[F]
    ok = (Fw[:, 0] != Fw[:, 1]) & (Fw[:, 1] != Fw[:, 2]) & (Fw[:, 0] != Fw[:, 2])
    F0 = F[ok]; Fw = Fw[ok]
    Fn, alive = decimate(Pw, Fw, target_faces, pin_seams=False, return_alive=True)
    src = F0[alive]                       # original corners of surviving faces
    out = src.copy()
    chg = Fn != inv[src]                  # corners whose welded vertex changed
    # copies per welded group
    order = np.argsort(inv, kind='stable'); starts = np.searchsorted(inv[order], np.arange(len(Pw)+1))
    fi, ci = np.nonzero(chg)
    for f, c in zip(fi, ci):
        g = Fn[f, c]; cand = order[starts[g]:starts[g+1]]
        if len(cand) == 1: out[f, c] = cand[0]; continue
        o = src[f, c]
        if UV is not None: d = ((UV[cand] - UV[o]) ** 2).sum(1)
        else: d = -(N[cand] * N[o]).sum(1)
        out[f, c] = cand[np.argmin(d)]
    return out

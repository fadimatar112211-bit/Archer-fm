const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs');
// usage: node drive.js file.glb outdir cfg.json
(async()=>{
  const [glbp,out,cfgp]=process.argv.slice(2); const cfg=JSON.parse(fs.readFileSync(cfgp));
  fs.mkdirSync(out,{recursive:true});
  const b=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
  const p=await b.newPage(); p.on('pageerror',e=>console.log('PAGEERR',e.message));
  await p.goto('file:///home/claude/viewer.html');
  const info=await p.evaluate(async d=>await loadGLB(d),fs.readFileSync(glbp).toString('base64'));
  const res={info,bounds:{}}; const skip=cfg.nobounds;
  for(const a of (skip?[]:info.names)){ res.bounds[a]=[];
    const n=12; for(let i=0;i<n;i++){const t=info.durs[a]*i/(n-1); res.bounds[a].push(await p.evaluate(([a,t])=>skinnedBounds(a,t),[a,t]));}
  }
  fs.writeFileSync(out+'/bounds.json',JSON.stringify(res));
  for(const f of cfg.frames){ const u=await p.evaluate(o=>renderFrame(o),f.opts); fs.writeFileSync(`${out}/${f.name}.png`,Buffer.from(u.split(',')[1],'base64')); }
  console.log(JSON.stringify(info)); await b.close();
})().catch(e=>{console.log('ERR',e.message.slice(0,500));process.exit(1)});

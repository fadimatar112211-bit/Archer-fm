import struct, json, numpy as np
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def load(p):
    b=open(p,'rb').read()
    cl,_=struct.unpack('<II',b[12:20]); j=json.loads(b[20:20+cl])
    o=20+cl; bl,_=struct.unpack('<II',b[o:o+8]); bin_=b[o+8:o+8+bl]
    return j,bin_
def acc(j,bin_,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    dt=np.dtype(CT[a['componentType']]); n=NC[a['type']]
    off=bv.get('byteOffset',0)+a.get('byteOffset',0)
    stride=bv.get('byteStride') or dt.itemsize*n
    if stride==dt.itemsize*n:
        arr=np.frombuffer(bin_,dt,a['count']*n,off).reshape(a['count'],n)
    else:
        arr=np.stack([np.frombuffer(bin_,dt,n,off+k*stride) for k in range(a['count'])])
    return arr.copy()

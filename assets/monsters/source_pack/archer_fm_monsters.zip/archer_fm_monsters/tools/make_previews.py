import json,subprocess,os
from PIL import Image,ImageDraw,ImageFont
A={a['name']:a for a in json.load(open('analysis.json'))}
H={'bog-monster':1.5,'werewolf':1.4,'stone-golem':1.9,'blind-stalker':1.3}
TITLE={'bog-monster':'Bog Monster','werewolf':'Werewolf','stone-golem':'Stone Golem','blind-stalker':'Blind Stalker'}
BG=(58,66,82); font=ImageFont.load_default(size=18) if hasattr(ImageFont,'load_default') else None
def run(n,frames,tag,nobounds=True):
    json.dump({"frames":frames,"nobounds":nobounds},open('c_tmp.json','w'))
    subprocess.run(['node','drive.js',f'build/{n}.glb',f'pv/{n}_{tag}','c_tmp.json'],check=True,capture_output=True)
os.makedirs('pv',exist_ok=True)
for n,h in H.items():
    d=3.7*h
    hero=[{"name":"hero","opts":{"anim":"Idle","time":0.8,"yaw":32,"pitch":20,"dist":d*0.82,"target":[0,h*0.5,0],"size":768}}]
    game=[{"name":"game","opts":{"anim":"Idle","time":0.8,"yaw":0,"pitch":55,"dist":d*0.9,"target":[0,h*0.45,0],"size":512}}]
    it=A[n]['attack']['impact_t']
    seq=[('Idle',0.8),('Walk',0.4),('Run',0.25),('Attack',it),('Roar',1.0),('Hit',0.16),('Die',2.2)]
    sheet=[{"name":a,"opts":{"anim":a,"time":t,"yaw":28,"pitch":38,"dist":d*(1.15 if a=="Die" else 1),"target":[0,h*(0.28 if a=="Die" else 0.5),0],"size":384}} for a,t in seq]
    run(n,hero,'hero'); run(n,game,'game'); run(n,sheet,'sheet')
    # compose
    hero_i=Image.open(f'pv/{n}_hero/hero.png').convert('RGBA'); bg=Image.new('RGBA',hero_i.size,BG+(255,)); bg.alpha_composite(hero_i); bg.convert('RGB').save(f'pv/{n}_preview_hero.png')
    hero_i.save(f'pv/{n}_preview_hero_transparent.png')
    g=Image.open(f'pv/{n}_game/game.png').convert('RGBA'); bg=Image.new('RGBA',g.size,BG+(255,)); bg.alpha_composite(g); bg.convert('RGB').save(f'pv/{n}_preview_game_camera.png')
    S=Image.new('RGB',(384*4,(384+0)*2),BG); dr=ImageDraw.Draw(S)
    for i,(a,t) in enumerate(seq):
        im=Image.open(f'pv/{n}_sheet/{a}.png').convert('RGBA'); x,y=(i%4)*384,(i//4)*384; S.paste(im,(x,y),im); dr.text((x+10,y+8),f'{a}  t={t:.2f}s',fill=(255,255,255),font=font)
    dr.text((384*3+10,384+8),TITLE[n],fill=(255,255,255),font=font); dr.text((384*3+10,384+34),'Archer FM - chibi pass',fill=(190,200,215),font=font)
    S.save(f'pv/{n}_preview_animations.png'); print(n,'ok')

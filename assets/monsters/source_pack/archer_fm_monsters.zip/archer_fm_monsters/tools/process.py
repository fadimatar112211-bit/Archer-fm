import json, struct, sys, copy, numpy as np
import glb
from decimate import decimate, decimate_welded, compact

CT_OF = {np.dtype(np.int8): 5120, np.dtype(np.uint8): 5121, np.dtype(np.int16): 5122, np.dtype(np.uint16): 5123,
         np.dtype(np.uint32): 5125, np.dtype(np.float32): 5126}
TYPE_OF = {1: 'SCALAR', 2: 'VEC2', 3: 'VEC3', 4: 'VEC4', 16: 'MAT4'}

CFG = {
 'bog-monster':   dict(title='Bog Monster',   budget=18000, head=1.70, thigh=0.78, arm=0.90, height=1.50, recoil=1.0),
 'werewolf':      dict(title='Werewolf',      budget=20000, head=1.70, thigh=0.78, arm=0.90, height=1.40, recoil=1.2),
 'stone-golem':   dict(title='Stone Golem',   budget=16000, head=1.55, thigh=0.82, arm=0.95, height=1.90, recoil=0.5),
 'blind-stalker': dict(title='Blind Stalker', budget=14000, head=1.70, thigh=0.82, arm=0.90, height=1.30, recoil=1.3),
}

# ---------- quaternion / matrix helpers
def qmul(a, b):
    x1, y1, z1, w1 = a; x2, y2, z2, w2 = b
    return np.array([w1*x2+x1*w2+y1*z2-z1*y2, w1*y2-x1*z2+y1*w2+z1*x2, w1*z2+x1*y2-y1*x2+z1*w2, w1*w2-x1*x2-y1*y2-z1*z2])
def qeuler(rx, ry, rz):
    def ax(a, v):
        h = np.radians(a) / 2; s = np.sin(h); return np.array([v[0]*s, v[1]*s, v[2]*s, np.cos(h)])
    return qmul(qmul(ax(rz, (0, 0, 1)), ax(ry, (0, 1, 0))), ax(rx, (1, 0, 0)))
def trs(t, q, s):
    x, y, z, w = q
    R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
    M = np.eye(4); M[:3, :3] = R * np.array(s)[None, :]; M[:3, 3] = t; return M

class Builder:
    def __init__(s): s.blob = bytearray(); s.bvs = []; s.accs = []
    def add(s, arr, target=None, minmax=False, normalized=False, ctype=None):
        arr = np.ascontiguousarray(arr)
        while len(s.blob) % 4: s.blob.append(0)
        s.bvs.append(dict(buffer=0, byteOffset=len(s.blob), byteLength=arr.nbytes, **({'target': target} if target else {})))
        s.blob += arr.tobytes()
        n = arr.shape[1] if arr.ndim > 1 else 1
        a = dict(bufferView=len(s.bvs)-1, componentType=CT_OF[arr.dtype], count=arr.shape[0], type=TYPE_OF[n])
        if normalized: a['normalized'] = True
        if minmax: a['min'] = arr.reshape(arr.shape[0], -1).min(0).astype(float).tolist(); a['max'] = arr.reshape(arr.shape[0], -1).max(0).astype(float).tolist()
        s.accs.append(a); return len(s.accs)-1
    def raw(s, data):
        while len(s.blob) % 4: s.blob.append(0)
        s.bvs.append(dict(buffer=0, byteOffset=len(s.blob), byteLength=len(data))); s.blob += data
        return len(s.bvs)-1

def write_glb(path, j, blob):
    j = copy.deepcopy(j); j['buffers'] = [dict(byteLength=len(blob))]
    js = json.dumps(j, separators=(',', ':')).encode()
    while len(js) % 4: js += b' '
    b = bytes(blob)
    while len(b) % 4: b += b'\0'
    total = 12 + 8 + len(js) + 8 + len(b)
    open(path, 'wb').write(struct.pack('<4sII', b'glTF', 2, total) + struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(b), b'BIN\0') + b)

def process(name, src, dst):
    c = CFG[name]
    j, b = glb.load(src); out = copy.deepcopy(j); B = Builder()
    nodes = out['nodes']; names = [n.get('name') for n in nodes]; ix = {n: i for i, n in enumerate(names) if n}
    # ---------- images (keep bytes as-is)
    for im in out['images']:
        bv = j['bufferViews'][im['bufferView']]; im['bufferView'] = B.raw(b[bv['byteOffset']:bv['byteOffset']+bv['byteLength']])
    # ---------- meshes: decimate each primitive
    prims = j['meshes'][0]['primitives']; total = sum(j['accessors'][p['indices']]['count']//3 for p in prims)
    ratio = min(1.0, c['budget'] / total); stats = []
    out_prims = []
    for p in prims:
        P = glb.acc(j, b, p['attributes']['POSITION']); F = glb.acc(j, b, p['indices']).reshape(-1, 3).astype(np.int64)
        W = glb.acc(j, b, p['attributes']['WEIGHTS_0']).astype(np.float32)
        if W.dtype != np.float32 or W.max() > 1.5: W = W / 255.0
        tgt = max(int(len(F) * ratio), 120)
        Nn = glb.acc(j, b, p['attributes']['NORMAL']).astype(np.float64)
        UV = glb.acc(j, b, p['attributes']['TEXCOORD_0']).astype(np.float64) if 'TEXCOORD_0' in p['attributes'] else None
        G = decimate_welded(P, F, Nn, UV, tgt) if tgt < len(F) else F
        attrs = {k: glb.acc(j, b, v) for k, v in p['attributes'].items()}
        G, arrs = compact(G, list(attrs.values())); attrs = dict(zip(attrs.keys(), arrs))
        na = {}
        for k, arr in attrs.items():
            meta = j['accessors'][p['attributes'][k]]
            na[k] = B.add(arr, target=34962, minmax=(k == 'POSITION'), normalized=meta.get('normalized', False))
        idx = G.reshape(-1).astype(np.uint16 if len(P) < 65535 else np.uint32)
        ii = B.add(idx, target=34963)
        q = dict(p); q['attributes'] = na; q['indices'] = ii; out_prims.append(q)
        stats.append((j['materials'][p['material']]['name'], len(F), len(G)))
    out['meshes'][0]['primitives'] = out_prims
    # ---------- skin IBM
    sk = out['skins'][0]; ibm = glb.acc(j, b, sk['inverseBindMatrices']); sk['inverseBindMatrices'] = B.add(ibm)
    # ---------- chibi proportions (node scales only; mesh + IBM untouched)
    def setscale(nm, s): nodes[ix[nm]]['scale'] = [s, s, s]
    setscale('Head', c['head'])
    for side in 'LR':
        setscale('Thigh_' + side, c['thigh']); setscale('Shoulder_' + side, c['arm'])
    # ---------- animations: read, then (a) shift Hips, (b) add Hit
    anims = {}
    for a in j['animations']:
        chans = []
        for ch in a['channels']:
            s = a['samplers'][ch['sampler']]
            chans.append(dict(node=ch['target']['node'], path=ch['target']['path'], t=glb.acc(j, b, s['input']).reshape(-1).astype(np.float32), v=glb.acc(j, b, s['output']).astype(np.float32)))
        anims[a['name']] = chans
    # forward kinematics @ Idle t0 for grounding
    parent = [-1]*len(nodes)
    for i, n in enumerate(nodes):
        for ch in n.get('children', []): parent[ch] = i
    def fk(pose):
        G = [None]*len(nodes)
        def g(i):
            if G[i] is None:
                n = nodes[i]; t, q, s = pose.get(i, (n.get('translation', [0, 0, 0]), n.get('rotation', [0, 0, 0, 1]), n.get('scale', [1, 1, 1])))
                L = trs(t, q, s); G[i] = L if parent[i] < 0 else g(parent[i]) @ L
            return G[i]
        for i in range(len(nodes)): g(i)
        return G
    def idle_pose():
        pose = {}
        for ch in anims['Idle']:
            n = nodes[ch['node']]
            t, q, s = pose.get(ch['node'], (list(n.get('translation', [0, 0, 0])), list(n.get('rotation', [0, 0, 0, 1])), list(n.get('scale', [1, 1, 1]))))
            if ch['path'] == 'rotation': q = ch['v'][0].tolist()
            elif ch['path'] == 'translation': t = ch['v'][0].tolist()
            pose[ch['node']] = (t, q, s)
        return pose
    # vertices of all prims, skinned at idle t0 -> min/max Y
    def skinned_bounds(pose):
        G = fk(pose); JM = np.array([G[jn] @ ibm[k].reshape(4, 4).T for k, jn in enumerate(sk['joints'])])
        mn = np.full(3, 1e9); mx = np.full(3, -1e9)
        for q in out_prims:
            pass
        return G, JM
    # use decimated arrays from builder source (recompute from out accessors)
    def read_out(acc_i):
        a = B.accs[acc_i]; bv = B.bvs[a['bufferView']]; n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
        dt = {5126: np.float32, 5121: np.uint8, 5123: np.uint16, 5125: np.uint32}[a['componentType']]
        return np.frombuffer(bytes(B.blob[bv['byteOffset']:bv['byteOffset']+bv['byteLength']]), dt).reshape(a['count'], n)
    allP, allJ, allW = [], [], []
    for q in out_prims:
        allP.append(read_out(q['attributes']['POSITION'])); allJ.append(read_out(q['attributes']['JOINTS_0']).astype(int))
        raw = read_out(q['attributes']['WEIGHTS_0']); div = {np.dtype(np.uint16): 65535.0, np.dtype(np.uint8): 255.0}.get(raw.dtype, 1.0); allW.append(raw.astype(np.float64) / div)
    Pall = np.concatenate(allP); Jall = np.concatenate(allJ); Wall = np.concatenate(allW)
    def bounds(pose):
        G = fk(pose); JM = np.array([G[jn] @ ibm[k].reshape(4, 4).T for k, jn in enumerate(sk['joints'])])
        Ph = np.concatenate([Pall, np.ones((len(Pall), 1))], 1); res = np.zeros((len(Pall), 3))
        for k in range(4):
            M = JM[Jall[:, k]]; res += Wall[:, k:k+1] * np.einsum('nij,nj->ni', M[:, :3, :], Ph)
        return res.min(0), res.max(0)
    # neutralise original Root offset, then ground the feet
    nodes[ix['Root']]['translation'] = [0, 0, 0]
    pose = idle_pose(); mn, mx = bounds(pose)
    # undo Root offset inside Idle? (Root has no channel) -> shift Hips by -minY
    dy = -float(mn[1])
    hips = ix['Hips']; nodes[hips]['translation'][1] += dy
    for nm, chans in anims.items():
        for ch in chans:
            if ch['node'] == hips and ch['path'] == 'translation': ch['v'][:, 1] += dy
    pose = idle_pose(); mn, mx = bounds(pose); height = float(mx[1] - mn[1])
    s_root = c['height'] / height; nodes[ix['Root']]['scale'] = [s_root]*3
    # ---------- Hit animation
    rec = c['recoil']; T = np.array([0, 0.06, 0.16, 0.30, 0.45], np.float32); E = np.array([0, 1, 0.8, 0.3, 0], np.float32)
    offs = {'Spine': (-8, 0, 0), 'Chest': (-14, 5, 0), 'Neck': (-10, 0, 0), 'Head': (-16, -6, 10),
            'Arm_L': (0, 0, 18), 'Arm_R': (0, 0, -18), 'Forearm_L': (-12, 0, 0), 'Forearm_R': (-12, 0, 0), 'Shin_L': (10, 0, 0), 'Shin_R': (10, 0, 0)}
    hit = []
    for ch in anims['Idle']:
        if ch['path'] == 'rotation':
            q0 = ch['v'][0].astype(np.float64); nm = names[ch['node']]; vals = []
            for e in E:
                if nm in offs: qo = qeuler(*[o*rec*e for o in offs[nm]]); q = qmul(qo, q0)
                else: q = q0
                vals.append(q/np.linalg.norm(q))
            hit.append(dict(node=ch['node'], path='rotation', t=T, v=np.array(vals, np.float32)))
        elif ch['path'] == 'translation':  # Hips
            t0 = ch['v'][0].astype(np.float64); vals = [t0 + np.array([0, -0.05, -0.10]) * rec * e / 1.0 for e in E]
            hit.append(dict(node=ch['node'], path='translation', t=T, v=np.array(vals, np.float32)))
    anims['Hit'] = hit
    # ---------- keep every animation above ground: per-key Root lift (the animation translation channel lives on Root) so skinned min-Y >= 0
    def sample_pose(chans, t):
        pose = {}
        for ch in chans:
            T = ch['t']; tt = min(t, float(T[-1]))
            k = 0 if len(T) == 1 else min(int(np.searchsorted(T, tt, side='right')) - 1, len(T) - 2)
            f = 0.0 if len(T) == 1 else (tt - T[k]) / (T[k+1] - T[k]); v0 = ch['v'][k].astype(np.float64); v1 = ch['v'][min(k+1, len(T)-1)].astype(np.float64)
            if ch['path'] == 'rotation':
                if np.dot(v0, v1) < 0: v1 = -v1
                v = v0 + (v1 - v0) * f; v = v / np.linalg.norm(v)
            else: v = v0 + (v1 - v0) * f
            n = nodes[ch['node']]; cur = pose.get(ch['node'], [list(n.get('translation', [0, 0, 0])), list(n.get('rotation', [0, 0, 0, 1])), list(n.get('scale', [1, 1, 1]))])
            cur[0 if ch['path'] == 'translation' else 1] = v.tolist(); pose[ch['node']] = cur
        return {k: tuple(v) for k, v in pose.items()}
    lifts = {}
    for nm in ['Walk', 'Run', 'Attack', 'Roar', 'Die', 'Hit']:
        hc = [ch for ch in anims[nm] if ch['node'] == ix['Root'] and ch['path'] == 'translation'][0]; mx_lift = 0.0
        for k, tk in enumerate(hc['t']):
            mn_k, _ = bounds(sample_pose(anims[nm], float(tk)))
            lift = max(0.0, -float(mn_k[1])); hc['v'][k, 1] += lift; mx_lift = max(mx_lift, lift)
        lifts[nm] = round(mx_lift, 3)
    # ---------- write animations
    out['animations'] = []
    for nm in ['Idle', 'Walk', 'Run', 'Attack', 'Roar', 'Die', 'Hit']:
        samplers, channels = [], []
        for ch in anims[nm]:
            ti = B.add(ch['t'].reshape(-1), minmax=True); vi = B.add(ch['v'])
            samplers.append(dict(input=ti, output=vi, interpolation='LINEAR'))
            channels.append(dict(sampler=len(samplers)-1, target=dict(node=ch['node'], path=ch['path'])))
        out['animations'].append(dict(name=nm, samplers=samplers, channels=channels))
    # ---------- metadata
    cr = f'"{c["title"]}" by vinish.dev (https://vinish.dev/free-3d-models/), CC BY 4.0 - adapted for Archer FM: chibi proportions, reduced polygon count, added Hit animation'
    out['asset']['copyright'] = cr; out['asset']['generator'] = 'Archer FM monster pipeline (derived from glTF-Transform output)'
    out['asset']['extras'] = dict(j['asset'].get('extras', {}), modified=True, modifications='chibi proportions via bone scales; polygon reduction; Hit animation added', credit=cr)
    out['bufferViews'] = B.bvs; out['accessors'] = B.accs
    write_glb(dst, out, B.blob)
    tris = sum(s[2] for s in stats)
    return dict(lifts=lifts, name=name, tris_before=total, tris_after=tris, prims=stats, height_before=height, root_scale=s_root, ground_shift=dy, size=len(B.blob))

if __name__ == '__main__':
    name = sys.argv[1]
    r = process(name, f'src/monsters/{name}.glb', f'build/{name}.glb')
    print(json.dumps(r, indent=1, default=float))

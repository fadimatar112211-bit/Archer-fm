// تجربة منفصلة:  flutter build apk -t lib/hero3d_demo.dart
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'hero3d.dart';

void main() => runApp(const MaterialApp(home: Demo()));

class Demo extends StatefulWidget {
  const Demo({super.key});
  @override
  State<Demo> createState() => _DemoState();
}

class _DemoState extends State<Demo> with SingleTickerProviderStateMixin {
  final heroes = [for (final id in ['flame', 'ranger', 'shadow', 'storm']) Hero3D(id, height: 150)];
  final frame = ValueNotifier<int>(0);
  late final Ticker ticker;
  int index = 0;
  Duration last = Duration.zero;
  Offset stick = Offset.zero, origin = Offset.zero;

  @override
  void initState() {
    super.initState();
    for (final h in heroes) {
      h.position = const Offset(180, 330);
      h.load();
    }
    ticker = createTicker((now) {
      final dt = ((now - last).inMicroseconds / 1e6).clamp(0.0, .05).toDouble();
      last = now;
      heroes[index].update(dt, stick);
      frame.value++;
    })..start();
  }

  @override
  void dispose() {
    ticker.dispose();
    frame.dispose();
    super.dispose();
  }

  Widget button(String label, VoidCallback tap) => ElevatedButton(onPressed: tap, child: Text(label));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff241a24),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: GestureDetector(
              onPanStart: (d) => origin = d.localPosition,
              onPanUpdate: (d) => stick = (d.localPosition - origin) / 50,
              onPanEnd: (_) => stick = Offset.zero,
              onPanCancel: () => stick = Offset.zero,
              child: CustomPaint(painter: _Painter(() => heroes[index], frame), size: Size.infinite),
            ),
          ),
          Wrap(spacing: 6, children: [
            button('بطل', () => setState(() => index = (index + 1) % 4)),
            button('كومبو', () => heroes[index].attack()),
            button('اندفاع', () => heroes[index].dash()),
            for (var n = 1; n <= 4; n++) button('ult $n', () => heroes[index].ultimate(n)),
            button('ضرر', () => heroes[index].hurt(25)),
            button('إحياء', () => heroes[index].revive()),
          ]),
        ]),
      ),
    );
  }
}

class _Painter extends CustomPainter {
  _Painter(this.hero, Listenable repaint) : super(repaint: repaint);
  final Hero3D Function() hero;
  @override
  void paint(Canvas canvas, Size size) => hero().paint(canvas);
  @override
  bool shouldRepaint(_Painter old) => true;
}
